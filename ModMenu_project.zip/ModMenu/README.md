# ModMenu — черновик (НЕ ПРОВЕРЕН НА УСТРОЙСТВЕ)

Меню появляется ТОЛЬКО в главном меню игры и пропадает в раунде.
Умеет: голубое/серое небо, свой счётчик перехватов (текст "N перехватов").
Не нужны ни dump.cs, ни адреса: всё ищется по стандартным названиям Unity.

## Что нужно на компьютере
1. Android Studio (с компонентами SDK и NDK/CMake — студия предложит поставить сама).
2. Git (чтобы скачать библиотеку Dobby).

## Сборка
1. Распакуйте архив, откройте папку ModMenu в Android Studio (File → Open).
2. В папке `app/src/main/cpp` выполните:
   git clone https://github.com/jmpews/Dobby
   (должна получиться папка app/src/main/cpp/Dobby)
3. Если Studio просит обновить версию Gradle/плагина — соглашайтесь.
4. Меню Build → Build Bundle(s)/APK(s) → Build APK(s).
   Получится app/build/outputs/apk/debug/app-debug.apk.

## Вариант А (проще): пришлите мне app-debug.apk, я сам встрою в игру
Тогда вам останется только добавить одну строку в манифест (шаг 3 ниже).

## Вариант Б: встроить вручную (MT Manager или 7-Zip)
Откройте app-debug.apk как архив и игровой APK как архив:
1. Из app-debug.apk скопируйте `classes.dex` в игровой APK под именем `classes4.dex`
   (если уже есть classes4.dex — берите следующий номер).
2. Скопируйте `lib/arm64-v8a/libmodmenu.so` в `lib/arm64-v8a/` игры.
3. Скопируйте папку `assets/modmenu` (6 PNG) в `assets/` игры.
4. В AndroidManifest.xml игры, перед `</application>`, добавьте строку:
   <provider android:name="com.mod.menu.ModInit" android:authorities="com.JamesWest.NoomiClone.modinit" android:exported="false" />
5. Подпишите APK (V1+V2+V3), удалите старую версию игры, установите.

## Если не заработало
Логи с тегом ModMenu: на компьютере `adb logcat -s ModMenu`.
Пришлите мне эти строки (они покажут, какой именно шаг не прошёл).
Важные строки: "JNI_OnLoad ok", "hook installed", "init: ...", "sky material found", "menu visible".

## Известные неопределённости
- Серое небо может оказаться вверх ногами или зеркальным: в меню есть кнопки "Перевернуть" и "Отразить".
- Если в игре нет текста со словом "перехват" в момент раунда, меню не спрячется.
- Игровой класс/методы могли быть вырезаны при сборке (stripping): тогда в логе будет null (0x0) у нужных методов.
