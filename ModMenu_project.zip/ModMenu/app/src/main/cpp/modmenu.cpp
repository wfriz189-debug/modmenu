// ModMenu: нативная часть. Работает через экспорт il2cpp_* (без адресов и без dump.cs).
// ПЕРВЫЙ НЕПРОВЕРЕННЫЙ ЧЕРНОВИК. Все логи: тег "ModMenu" (adb logcat -s ModMenu).
#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <pthread.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <cstring>
#include <cstdint>

// Прототип Dobby, объявляем сами, чтобы не зависеть от версии заголовка
extern "C" int DobbyHook(void* address, void* replace, void** origin);

#define TAG "ModMenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ============ il2cpp API ============
#define API(ret, name, args) static ret (*name) args = nullptr;
API(void*, il2cpp_domain_get, ())
API(void*, il2cpp_thread_attach, (void*))
API(void**, il2cpp_domain_get_assemblies, (void*, size_t*))
API(void*, il2cpp_assembly_get_image, (void*))
API(void*, il2cpp_class_from_name, (void*, const char*, const char*))
API(void*, il2cpp_class_get_methods, (void*, void**))
API(void*, il2cpp_class_get_parent, (void*))
API(void*, il2cpp_class_get_type, (void*))
API(void*, il2cpp_type_get_object, (void*))
API(const char*, il2cpp_method_get_name, (void*))
API(uint32_t, il2cpp_method_get_param_count, (void*))
API(void*, il2cpp_method_get_param, (void*, uint32_t))
API(char*, il2cpp_type_get_name, (void*))
API(void*, il2cpp_runtime_invoke, (void*, void*, void**, void**))
API(void*, il2cpp_string_new, (const char*))
API(int32_t, il2cpp_string_length, (void*))
API(uint16_t*, il2cpp_string_chars, (void*))
API(void*, il2cpp_object_new, (void*))
API(void*, il2cpp_object_unbox, (void*))
API(void*, il2cpp_array_new, (void*, uintptr_t))
API(void*, il2cpp_array_addr_with_size, (void*, int32_t, uintptr_t))
API(uint32_t, il2cpp_array_length, (void*))
API(uint32_t, il2cpp_gchandle_new, (void*, int))

static bool resolveApi(void* h) {
#define R(n) n = (decltype(n))dlsym(h, #n); if (!n) { LOGE("missing api %s", #n); return false; }
    R(il2cpp_domain_get) R(il2cpp_thread_attach) R(il2cpp_domain_get_assemblies)
    R(il2cpp_assembly_get_image) R(il2cpp_class_from_name) R(il2cpp_class_get_methods)
    R(il2cpp_class_get_parent) R(il2cpp_class_get_type) R(il2cpp_type_get_object)
    R(il2cpp_method_get_name) R(il2cpp_method_get_param_count) R(il2cpp_method_get_param)
    R(il2cpp_type_get_name) R(il2cpp_runtime_invoke) R(il2cpp_string_new)
    R(il2cpp_string_length) R(il2cpp_string_chars) R(il2cpp_object_new) R(il2cpp_object_unbox)
    R(il2cpp_array_new) R(il2cpp_array_addr_with_size) R(il2cpp_array_length) R(il2cpp_gchandle_new)
#undef R
    return true;
}

// ============ глобальное состояние ============
static JavaVM* g_vm = nullptr;
static jclass g_cls = nullptr;
static jmethodID g_midVis = nullptr;
static void* g_domain = nullptr;

static std::mutex g_mx;
static std::vector<std::vector<uint8_t>> g_faces;      // 6 PNG
static std::atomic<int> g_skyWant(-1);                 // -1 ничего, 0 голубое, 1 серое
static std::atomic<int> g_skyVer(0);
static std::atomic<bool> g_counterOn(false);
static std::string g_counterText;

// ============ поиск классов и методов ============
static void* findClass(const char* ns, const char* name) {
    size_t n = 0;
    void** asms = il2cpp_domain_get_assemblies(g_domain, &n);
    for (size_t i = 0; i < n; i++) {
        void* img = il2cpp_assembly_get_image(asms[i]);
        void* k = il2cpp_class_from_name(img, ns, name);
        if (k) return k;
    }
    return nullptr;
}

static void* findMethod(void* klass, const char* name, int argc, std::vector<const char*> sig = {}) {
    for (void* k = klass; k; k = il2cpp_class_get_parent(k)) {
        void* iter = nullptr;
        void* m;
        while ((m = il2cpp_class_get_methods(k, &iter))) {
            if (strcmp(il2cpp_method_get_name(m), name) != 0) continue;
            if ((int)il2cpp_method_get_param_count(m) != argc) continue;
            bool ok = true;
            for (size_t i = 0; i < sig.size() && ok; i++) {
                char* tn = il2cpp_type_get_name(il2cpp_method_get_param(m, (uint32_t)i));
                ok = tn && strcmp(tn, sig[i]) == 0;
            }
            if (ok) return m;
        }
    }
    return nullptr;
}

static void* inv(void* method, void* obj, void** params) {
    void* exc = nullptr;
    void* r = il2cpp_runtime_invoke(method, obj, params, &exc);
    if (exc) { LOGE("exception in %s", il2cpp_method_get_name(method)); return nullptr; }
    return r;
}

static std::u16string strOf(void* s) {
    if (!s) return u"";
    return std::u16string((const char16_t*)il2cpp_string_chars(s), (size_t)il2cpp_string_length(s));
}

// ============ классы/методы Unity ============
static void *kTMP, *kMaterial, *kResources, *kObject, *kTex2D, *kCubemap, *kImgConv, *kByte;
static void *mFindAll, *mGetText, *mSetText, *mActive, *mGetName;
static void *mGetTexture, *mSetTexture, *mCubeCtor, *mTexCtor, *mLoadImage, *mGetPixels32, *mSetPixels32, *mCubeApply;
static void *tTMP, *tMaterial;

static bool initTick() {
    kTMP = findClass("TMPro", "TMP_Text");
    kMaterial = findClass("UnityEngine", "Material");
    kResources = findClass("UnityEngine", "Resources");
    kObject = findClass("UnityEngine", "Object");
    kTex2D = findClass("UnityEngine", "Texture2D");
    kCubemap = findClass("UnityEngine", "Cubemap");
    kImgConv = findClass("UnityEngine", "ImageConversion");
    kByte = findClass("System", "Byte");
    if (!kMaterial || !kResources || !kObject) { LOGE("core classes missing"); return false; }

    mFindAll = findMethod(kResources, "FindObjectsOfTypeAll", 1, {"System.Type"});
    mGetName = findMethod(kObject, "get_name", 0);
    if (kTMP) {
        mGetText = findMethod(kTMP, "get_text", 0);
        mSetText = findMethod(kTMP, "set_text", 1, {"System.String"});
        mActive = findMethod(kTMP, "get_isActiveAndEnabled", 0);
        tTMP = il2cpp_type_get_object(il2cpp_class_get_type(kTMP));
    }
    tMaterial = il2cpp_type_get_object(il2cpp_class_get_type(kMaterial));
    mGetTexture = findMethod(kMaterial, "GetTexture", 1, {"System.String"});
    mSetTexture = findMethod(kMaterial, "SetTexture", 2, {"System.String", "UnityEngine.Texture"});
    if (kCubemap) {
        mCubeCtor = findMethod(kCubemap, ".ctor", 3, {"System.Int32", "UnityEngine.TextureFormat", "System.Boolean"});
        mSetPixels32 = findMethod(kCubemap, "SetPixels32", 2, {"UnityEngine.Color32[]", "UnityEngine.CubemapFace"});
        mCubeApply = findMethod(kCubemap, "Apply", 2, {"System.Boolean", "System.Boolean"});
    }
    if (kTex2D) {
        mTexCtor = findMethod(kTex2D, ".ctor", 2, {"System.Int32", "System.Int32"});
        mGetPixels32 = findMethod(kTex2D, "GetPixels32", 0);
    }
    if (kImgConv) mLoadImage = findMethod(kImgConv, "LoadImage", 2, {"UnityEngine.Texture2D", "System.Byte[]"});

    LOGI("init: FindAll=%p GetText=%p SetText=%p Active=%p GetTexture=%p SetTexture=%p CubeCtor=%p Tex2DCtor=%p LoadImage=%p GetPixels32=%p SetPixels32=%p Apply=%p",
         mFindAll, mGetText, mSetText, mActive, mGetTexture, mSetTexture, mCubeCtor, mTexCtor, mLoadImage, mGetPixels32, mSetPixels32, mCubeApply);
    return mFindAll != nullptr;
}

// ============ небо ============
static void* g_lastMat = nullptr;
static void* g_origTex = nullptr;
static void* g_cube = nullptr;
static int g_cubeVer = -1;
static int g_applied = -1, g_appliedVer = -1;

static void* findSkyMaterial() {
    if (!mFindAll || !mGetName) return nullptr;
    void* p[1] = {tMaterial};
    void* arr = inv(mFindAll, nullptr, p);
    if (!arr) return nullptr;
    uint32_t n = il2cpp_array_length(arr);
    for (uint32_t i = 0; i < n; i++) {
        void* o = *(void**)il2cpp_array_addr_with_size(arr, sizeof(void*), i);
        if (!o) continue;
        std::u16string nm = strOf(inv(mGetName, o, nullptr));
        if (nm == u"FS000_Day_05_Sunless") return o;
    }
    return nullptr;
}

static void* buildCubemap() {
    if (!mCubeCtor || !mTexCtor || !mLoadImage || !mGetPixels32 || !mSetPixels32 || !kByte) {
        LOGE("cubemap api missing"); return nullptr;
    }
    std::vector<std::vector<uint8_t>> faces;
    { std::lock_guard<std::mutex> l(g_mx); faces = g_faces; }
    if (faces.size() != 6) return nullptr;

    int size = 512, fmt = 4 /*RGBA32*/; bool mip = false;
    void* cm = il2cpp_object_new(kCubemap);
    void* pc[3] = {&size, &fmt, &mip};
    inv(mCubeCtor, cm, pc);
    for (int i = 0; i < 6; i++) {
        void* tex = il2cpp_object_new(kTex2D);
        int w = 2, h = 2; void* pt[2] = {&w, &h};
        inv(mTexCtor, tex, pt);
        void* arr = il2cpp_array_new(kByte, faces[i].size());
        memcpy(il2cpp_array_addr_with_size(arr, 1, 0), faces[i].data(), faces[i].size());
        void* pl[2] = {tex, arr};
        inv(mLoadImage, nullptr, pl);
        void* px = inv(mGetPixels32, tex, nullptr);
        int face = i; void* ps[2] = {px, &face};
        inv(mSetPixels32, cm, ps);
    }
    if (mCubeApply) { bool b1 = false, b2 = false; void* pa[2] = {&b1, &b2}; inv(mCubeApply, cm, pa); }
    il2cpp_gchandle_new(cm, 0);  // не даём GC удалить
    LOGI("cubemap built");
    return cm;
}

static void setTex(void* mat, void* tex) {
    if (!mSetTexture || !tex) return;
    void* p[2] = {il2cpp_string_new("_Tex"), tex};
    inv(mSetTexture, mat, p);
}

static void updateSky() {
    void* mat = findSkyMaterial();
    if (!mat) return;
    if (mat != g_lastMat) {
        g_lastMat = mat;
        void* p[1] = {il2cpp_string_new("_Tex")};
        g_origTex = mGetTexture ? inv(mGetTexture, mat, p) : nullptr;
        if (g_origTex) il2cpp_gchandle_new(g_origTex, 0);
        g_applied = -1;
        LOGI("sky material found %p orig=%p", mat, g_origTex);
    }
    int want = g_skyWant.load(), ver = g_skyVer.load();
    if (want < 0) return;
    if (g_applied == want && g_appliedVer == ver) return;
    if (want == 0) {
        setTex(mat, g_origTex);
    } else {
        if (g_cubeVer != ver) { g_cube = buildCubemap(); g_cubeVer = ver; }
        setTex(mat, g_cube);
    }
    g_applied = want; g_appliedVer = ver;
    LOGI("sky applied: %d", want);
}

// ============ счётчик + определение "мы в игре" ============
static int g_menuState = -1;

static void callSetMenuVisible(bool v) {
    if (!g_vm || !g_cls || !g_midVis) return;
    JNIEnv* env = nullptr;
    bool att = false;
    if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        att = true;
    }
    env->CallStaticVoidMethod(g_cls, g_midVis, (jboolean)v);
    if (att) g_vm->DetachCurrentThread();
}

static std::u16string utf8to16(const std::string& s) {
    std::u16string r;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = s[i];
        uint32_t cp; int len;
        if (c < 0x80) { cp = c; len = 1; }
        else if ((c >> 5) == 6) { cp = c & 0x1F; len = 2; }
        else if ((c >> 4) == 14) { cp = c & 0x0F; len = 3; }
        else { cp = c & 0x07; len = 4; }
        for (int k = 1; k < len && i + k < s.size(); k++) cp = (cp << 6) | (s[i + k] & 0x3F);
        i += len;
        if (cp < 0x10000) r.push_back((char16_t)cp);
        else { cp -= 0x10000; r.push_back((char16_t)(0xD800 + (cp >> 10))); r.push_back((char16_t)(0xDC00 + (cp & 0x3FF))); }
    }
    return r;
}

static void updateCounter() {
    bool gameplay = false;
    if (mFindAll && tTMP && mGetText) {
        void* p[1] = {tTMP};
        void* arr = inv(mFindAll, nullptr, p);
        if (arr) {
            uint32_t n = il2cpp_array_length(arr);
            std::string num;
            { std::lock_guard<std::mutex> l(g_mx); num = g_counterText; }
            for (uint32_t i = 0; i < n; i++) {
                void* o = *(void**)il2cpp_array_addr_with_size(arr, sizeof(void*), i);
                if (!o) continue;
                if (mActive) {
                    void* r = inv(mActive, o, nullptr);
                    if (!r || !*(bool*)il2cpp_object_unbox(r)) continue;
                }
                std::u16string t = strOf(inv(mGetText, o, nullptr));
                if (t.find(u"перехват") == std::u16string::npos) continue;
                gameplay = true;
                if (g_counterOn.load() && mSetText && !num.empty()) {
                    std::string full = num + " перехватов";
                    std::u16string want = utf8to16(full);
                    if (t != want) {
                        void* ps[1] = {il2cpp_string_new(full.c_str())};
                        inv(mSetText, o, ps);
                    }
                }
            }
        }
    }
    int st = gameplay ? 0 : 1;
    if (st != g_menuState) {
        g_menuState = st;
        LOGI("menu visible: %d", st);
        callSetMenuVisible(st == 1);
    }
}

// ============ вызывается каждый кадр (главный поток Unity) ============
static void tick() {
    static bool inited = false;
    if (!inited) { inited = initTick(); if (!inited) return; }
    updateSky();
    updateCounter();
}

static void (*orig_SendWillRender)(void*) = nullptr;
static void hook_SendWillRender(void* mi) {
    static int n = 0;
    if (++n % 15 == 0) tick();
    if (orig_SendWillRender) orig_SendWillRender(mi);
}

// ============ поток-установщик хука ============
static void* worker(void*) {
    bool api = false;
    for (int i = 0; i < 3000; i++) {  // ~10 минут максимум
        usleep(200000);
        void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
        if (!h) continue;
        if (!api) { api = resolveApi(h); if (!api) return nullptr; }
        void* dom = il2cpp_domain_get();
        if (!dom) continue;
        g_domain = dom;
        il2cpp_thread_attach(dom);
        void* canvas = findClass("UnityEngine", "Canvas");
        if (!canvas) continue;
        void* mi = findMethod(canvas, "SendWillRenderCanvases", 0);
        if (!mi) { LOGE("SendWillRenderCanvases not found"); return nullptr; }
        void* fn = *(void**)mi;  // MethodInfo.methodPointer
        if (!fn) { LOGE("null methodPointer"); return nullptr; }
        int r = DobbyHook(fn, (void*)hook_SendWillRender, (void**)&orig_SendWillRender);
        LOGI("hook installed: %d (fn=%p)", r, fn);
        return nullptr;
    }
    LOGE("il2cpp never became ready");
    return nullptr;
}

// ============ JNI ============
extern "C" JNIEXPORT void JNICALL
Java_com_mod_menu_ModInit_nativeSetSky(JNIEnv* env, jclass, jint mode, jobjectArray faces) {
    if (mode == 1 && faces) {
        std::vector<std::vector<uint8_t>> v;
        jsize n = env->GetArrayLength(faces);
        for (jsize i = 0; i < n; i++) {
            jbyteArray a = (jbyteArray)env->GetObjectArrayElement(faces, i);
            jsize len = env->GetArrayLength(a);
            std::vector<uint8_t> b(len);
            env->GetByteArrayRegion(a, 0, len, (jbyte*)b.data());
            v.push_back(std::move(b));
            env->DeleteLocalRef(a);
        }
        { std::lock_guard<std::mutex> l(g_mx); g_faces = std::move(v); }
        g_skyVer++;
    }
    g_skyWant = mode;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mod_menu_ModInit_nativeSetCounter(JNIEnv* env, jclass, jstring text, jboolean enabled) {
    const char* s = text ? env->GetStringUTFChars(text, nullptr) : "";
    { std::lock_guard<std::mutex> l(g_mx); g_counterText = s ? s : ""; }
    if (text && s) env->ReleaseStringUTFChars(text, s);
    g_counterOn = enabled;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;
    jclass c = env->FindClass("com/mod/menu/ModInit");
    if (c) {
        g_cls = (jclass)env->NewGlobalRef(c);
        g_midVis = env->GetStaticMethodID(g_cls, "setMenuVisible", "(Z)V");
    }
    pthread_t t;
    pthread_create(&t, nullptr, worker, nullptr);
    pthread_detach(t);
    LOGI("JNI_OnLoad ok");
    return JNI_VERSION_1_6;
}
