package com.mod.menu;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Старт мода: ContentProvider создаётся системой до запуска игры,
 * поэтому не нужно править smali. Достаточно добавить <provider> в манифест игры.
 */
public class ModInit extends ContentProvider {
    static final String TAG = "ModMenu";

    static {
        try {
            System.loadLibrary("modmenu");
        } catch (Throwable t) {
            Log.e(TAG, "loadLibrary failed", t);
        }
    }

    // ---- native ----
    static native void nativeSetSky(int mode, byte[][] faces);
    static native void nativeSetCounter(String text, boolean enabled);

    // ---- state ----
    static LinearLayout panel;
    static SharedPreferences prefs;
    static boolean flipV = true;   // если серое небо вверх ногами - нажмите кнопку "Перевернуть"
    static boolean flipH = false;
    static boolean menuVisible = true;
    static final Handler ui = new Handler(Looper.getMainLooper());

    /** Вызывается из нативного кода: true = главное меню, false = игра. */
    public static void setMenuVisible(final boolean v) {
        menuVisible = v;
        ui.post(new Runnable() {
            @Override public void run() {
                if (panel != null) panel.setVisibility(v ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public boolean onCreate() {
        try {
            Context c = getContext();
            Application app = (Application) c.getApplicationContext();
            prefs = c.getSharedPreferences("modmenu", Context.MODE_PRIVATE);
            flipV = prefs.getBoolean("flipV", true);
            flipH = prefs.getBoolean("flipH", false);
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityResumed(Activity a) { attach(a); }
                @Override public void onActivityCreated(Activity a, Bundle b) {}
                @Override public void onActivityStarted(Activity a) {}
                @Override public void onActivityPaused(Activity a) {}
                @Override public void onActivityStopped(Activity a) {}
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
                @Override public void onActivityDestroyed(Activity a) {}
            });
        } catch (Throwable t) {
            Log.e(TAG, "onCreate", t);
        }
        return true;
    }

    // ---- UI ----
    static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static Button btn(final Context c, String text, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        b.setLayoutParams(lp);
        return b;
    }

    static LinearLayout row(Context c) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    static void attach(final Activity a) {
        try {
            if (panel != null && panel.getContext() == a && panel.getParent() != null) return;
            if (panel != null && panel.getParent() instanceof ViewGroup) {
                ((ViewGroup) panel.getParent()).removeView(panel);
            }
            panel = build(a);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(a, 260), ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.END);
            lp.setMargins(0, dp(a, 8), dp(a, 8), 0);
            ((ViewGroup) a.getWindow().getDecorView()).addView(panel, lp);
            panel.setVisibility(menuVisible ? View.VISIBLE : View.GONE);
            Log.i(TAG, "panel attached");

            // восстановить сохранённые настройки
            if (prefs.getInt("sky", 0) == 1) applyGray(a);
            if (prefs.getBoolean("counterOn", false)) {
                nativeSetCounter(prefs.getString("counter", ""), true);
            }
        } catch (Throwable t) {
            Log.e(TAG, "attach", t);
        }
    }

    static LinearLayout build(final Activity a) {
        LinearLayout p = new LinearLayout(a);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xCC11151C);
        bg.setCornerRadius(dp(a, 12));
        p.setBackground(bg);

        TextView title = new TextView(a);
        title.setText("Мод-меню");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(15);
        p.addView(title);

        LinearLayout r1 = row(a);
        r1.addView(btn(a, "Голубое небо", new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().putInt("sky", 0).apply();
                nativeSetSky(0, null);
            }
        }));
        r1.addView(btn(a, "Серое небо", new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().putInt("sky", 1).apply();
                applyGray(a);
            }
        }));
        p.addView(r1);

        LinearLayout r2 = row(a);
        r2.addView(btn(a, "Перевернуть", new View.OnClickListener() {
            @Override public void onClick(View v) {
                flipV = !flipV;
                prefs.edit().putBoolean("flipV", flipV).apply();
                if (prefs.getInt("sky", 0) == 1) applyGray(a);
            }
        }));
        r2.addView(btn(a, "Отразить", new View.OnClickListener() {
            @Override public void onClick(View v) {
                flipH = !flipH;
                prefs.edit().putBoolean("flipH", flipH).apply();
                if (prefs.getInt("sky", 0) == 1) applyGray(a);
            }
        }));
        p.addView(r2);

        TextView lbl = new TextView(a);
        lbl.setText("Число перехватов:");
        lbl.setTextColor(0xFFCCCCCC);
        lbl.setTextSize(12);
        p.addView(lbl);

        final EditText et = new EditText(a);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("например 148867");
        et.setTextColor(0xFFFFFFFF);
        et.setHintTextColor(0xFF888888);
        et.setTextSize(14);
        et.setText(prefs.getString("counter", ""));
        p.addView(et);

        LinearLayout r3 = row(a);
        r3.addView(btn(a, "Применить", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String s = et.getText().toString().trim();
                if (s.length() == 0) return;
                prefs.edit().putString("counter", s).putBoolean("counterOn", true).apply();
                nativeSetCounter(s, true);
                Toast.makeText(a, "Счётчик: " + s, Toast.LENGTH_SHORT).show();
            }
        }));
        r3.addView(btn(a, "Выкл", new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().putBoolean("counterOn", false).apply();
                nativeSetCounter("", false);
            }
        }));
        p.addView(r3);
        return p;
    }

    /** Загружает 6 граней серого неба из assets/modmenu и отправляет в игру. */
    static void applyGray(Activity a) {
        try {
            byte[][] faces = new byte[6][];
            for (int i = 0; i < 6; i++) {
                InputStream in = a.getAssets().open("modmenu/sky_" + i + ".png");
                Bitmap b = BitmapFactory.decodeStream(in);
                in.close();
                Matrix m = new Matrix();
                m.postScale(flipH ? -1f : 1f, flipV ? -1f : 1f);
                Bitmap t = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, false);
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                t.compress(Bitmap.CompressFormat.PNG, 100, o);
                faces[i] = o.toByteArray();
            }
            nativeSetSky(1, faces);
        } catch (Throwable t) {
            Log.e(TAG, "applyGray", t);
        }
    }

    // ---- ContentProvider заглушки ----
    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
